Alexis LINKE

La recherche des motifs ne fonctionne par correctement, cela doit �tre d� � un souci lors de l'�valuation de la liste des points � appareiller.